	IMPORT |wram_globals0$$Base|
	IMPORT nes_reset
	IMPORT default_scanlinehook
	IMPORT pcm_scanlinehook
	IMPORT irq6502
	IMPORT PAL60
	IMPORT cpustate
	IMPORT rommap
	IMPORT dontstop
	END
