	IMPORT Konami_Init
	IMPORT Konami_IRQ_Hook
	IMPORT KoLatch
	IMPORT KoLatchLo
	IMPORT KoLatchHi
	IMPORT KoCounter
	IMPORT KoIRQen
	IMPORT Konami_IRQ_Hook
	END
