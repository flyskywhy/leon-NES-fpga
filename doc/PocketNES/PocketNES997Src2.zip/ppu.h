	IMPORT ppu_init
	IMPORT ppureset_
	IMPORT PPU_R
	IMPORT PPU_W
	IMPORT agb_nt_map
	IMPORT VRAM_chr
	IMPORT vram_map
	IMPORT vram_write_tbl
	IMPORT debug_
	IMPORT map_palette
	IMPORT newframe
	IMPORT agb_pal
	IMPORT ppustate
	IMPORT writeBG
	IMPORT oambuffer
	IMPORT newX
	IMPORT ctrl1_W
	END
