	IMPORT thumbcall_r1
	IMPORT IO_reset_
	IMPORT IO_R
	IMPORT IO_W
	IMPORT joypad_write_ptr
	IMPORT joy0_W
	IMPORT suspend
	IMPORT refreshNESjoypads
	IMPORT serialinterrupt
	END
