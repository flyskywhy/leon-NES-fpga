//
// HAM (c) Emanuel Schleussinger 2001/2002
// all rights reserved.
//
// Includes Doxygen compatible documentation
// http://www.doxygen.org
//


/*
----------------------------------------------------------

    REG_     --> Register location
	          absolute adress of a register.
		  includes typecasting for direct c writes.
                  example: R_DISPCNT = value;

	MEN_     --> MEMORY address


    V_       --> Value
	          A register related value used by macros
                  and functions. Register Masks are also
                  treated as values, this is currently in-
                  consistent with C_ (constants), which they
                  should be really. Anyone want to clean up? :-)

    C_       --> Constant
                  Helpers that will never need change. holds
                  values for bitfields that are hard to remember
                  Also note, C_'s might get declared only once
                  for a set of registers. If so, two rules apply:
                   - the C_ declaration always is in the first
                     register of the set.
                   - the number of the register (example BG0CNT,
                     BG1CNT) is set to C_BGXCNT.

    F_       --> Function
	          a function returns a value suchas true

    M_       --> Macro
	          A macro does stuff on its own, suchas
		  switching a display mode or enabling
		  sprites. This is what you will be using
                  most of the time. Example:
                  M_INTMST_ENABLE will enable interrupts

    TOOL_    --> Tool function
                  Usually a collection of macros and/or
                  functions. Propably not the fastest on
                  earth, but very convienient. These are
                  found at the end of the file. For example
                  TOOL_INIT_ALL(1) sets up the display for
                  BGMode 1 and inits sound and interrupts.


    Notes:
    ------
    Some of the functions/macros are not the fastest on
    earth, i know that. Most of them are built for
    convienience rather than speed, and will suffice
    in the most cases.

    Also, please do not mail me about the fact that
    using REG= A | B | C | D is faster than what
    is being done here. I know that ;-) First of all, that
    only applies sometimes (if you need to set whole bitfields),
    and second of all, you can still do it on your own using
    the R_ defines. I do the same in my code, but it proves
    handy to have the base cases covered.

    Disclaimer:
    -----------
    I'd like to be greeted in your demo if you use this
    header :)

    Be fair.

    Also, this source file and any other part of HAM must NOT:

     - be changed and redistributed as new versions, I
       would like to keep the main distribution point on
       my end. Help with any suggestions please, though.
       You WILL be mentioned for any help you did on HAM,
       and also, you can join in the team.

---------------------------------------------------------
*/


#ifndef _GBA_H_
#define _GBA_H_

// bool is a standard type in cplusplus, but not in c.
#ifndef __cplusplus
typedef     unsigned char           bool;
#endif
typedef     unsigned char           u8;
typedef     unsigned short int      u16;
typedef     unsigned int            u32;
typedef     unsigned long long int  u64;

typedef     signed char             s8;
typedef     signed short int        s16;
typedef     signed int              s32;
typedef     signed long long int    s64;

typedef     volatile unsigned char           vu8;
typedef     volatile unsigned short int      vu16;
typedef     volatile unsigned int            vu32;
typedef     volatile unsigned long long int  vu64;

typedef     volatile signed char             vs8;
typedef     volatile signed short int        vs16;
typedef     volatile signed int              vs32;
typedef     volatile signed long long int    vs64;


// boolean defines
#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef NULL
#define NULL ((void *)0)
#endif

// boolean defines
#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

#define BIT0    0x0001
#define BIT1    0x0002
#define BIT2    0x0004
#define BIT3    0x0008
#define BIT4    0x0010
#define BIT5    0x0020
#define BIT6    0x0040
#define BIT7    0x0080
#define BIT8    0x0100
#define BIT9    0x0200
#define BIT10   0x0400
#define BIT11   0x0800
#define BIT12   0x1000
#define BIT13   0x2000
#define BIT14   0x4000
#define BIT15   0x8000

// Bit operate macro
#define setb(c,b)		c|=(1<<(b))				//set the selected bit in the charecter
#define clrb(c,b)		c&=(~(1<<(b)))			//clr the selected bit in the charecter
#define testb(c,b)		(c&(1<<(b)))				//test the selected bit in the charecter is 0 or 1
// max value
#define max(a,b) ((a>b)?a:b)
// min value
#define min(a,b) ((a>b)?b:a)


/*
--------------------------------------------------------
 conversion defines
--------------------------------------------------------
*/
#define RGB(r,g,b) ((((b)>>3)<<10)+(((g)>>3)<<5)+((r)>>3))
#define RGB_SET(r,g,b) (((b)<<10)+((g)<<5)+(r));

#define RGB_GET_R_VALUE(rgb)    ((rgb & 0x001f) << 3)
#define RGB_GET_G_VALUE(rgb)    (((rgb >> 5) & 0x001f) << 3)
#define RGB_GET_B_VALUE(rgb)    (((rgb >> 10) & 0x001f) << 3)

#define PI 3.1415926
#define RADIAN(n) (((n)*PI)/180)

/*
------------------------------------------------------

	display mem pointer

------------------------------------------------------
*/

#define OAMmem         (u32*)0x7000000
#define VideoBuffer    (u16*)0x6000000
#define OAMdata		   (u16*)0x6100000
#define BGPaletteMem   (u16*)0x5000000
#define OBJPaletteMem  (u16*)0x5000200

/*
------------------------------------------------------

	regist of AGB

------------------------------------------------------
*/
#define REG_INTERUPT   *(volatile u32*)0x3007FFC		// save the irq func pointer

#define REG_DISPCNT    *(volatile u16*)0x4000000
#define REG_DISPSTAT   *(volatile u16*)0x4000004
#define REG_VCOUNT     *(volatile u16*)0x4000006
#define REG_BG0CNT     *(volatile u16*)0x4000008
#define REG_BG1CNT     *(volatile u16*)0x400000A
#define REG_BG2CNT     *(volatile u16*)0x400000C
#define REG_BG3CNT     *(volatile u16*)0x400000E
#define REG_BG0HOFS    *(volatile u16*)0x4000010
#define REG_BG0VOFS    *(volatile u16*)0x4000012
#define REG_BG1HOFS    *(volatile u16*)0x4000014
#define REG_BG1VOFS    *(volatile u16*)0x4000016
#define REG_BG2HOFS    *(volatile u16*)0x4000018
#define REG_BG2VOFS    *(volatile u16*)0x400001A
#define REG_BG3HOFS    *(volatile u16*)0x400001C
#define REG_BG3VOFS    *(volatile u16*)0x400001E
#define REG_BG2PA      *(volatile u16*)0x4000020
#define REG_BG2PB      *(volatile u16*)0x4000022
#define REG_BG2PC      *(volatile u16*)0x4000024
#define REG_BG2PD      *(volatile u16*)0x4000026
#define REG_BG2X       *(volatile u32*)0x4000028
#define REG_BG2X_L     *(volatile u16*)0x4000028
#define REG_BG2X_H     *(volatile u16*)0x400002A
#define REG_BG2Y       *(volatile u32*)0x400002C
#define REG_BG2Y_L     *(volatile u16*)0x400002C
#define REG_BG2Y_H     *(volatile u16*)0x400002E
#define REG_BG3PA      *(volatile u16*)0x4000030
#define REG_BG3PB      *(volatile u16*)0x4000032
#define REG_BG3PC      *(volatile u16*)0x4000034
#define REG_BG3PD      *(volatile u16*)0x4000036
#define REG_BG3X       *(volatile u32*)0x4000038
#define REG_BG3X_L     *(volatile u16*)0x4000038
#define REG_BG3X_H     *(volatile u16*)0x400003A
#define REG_BG3Y       *(volatile u32*)0x400003C
#define REG_BG3Y_L     *(volatile u16*)0x400003C
#define REG_BG3Y_H     *(volatile u16*)0x400003E
#define REG_WIN0H      *(volatile u16*)0x4000040
#define REG_WIN0X      *(volatile u16*)0x4000040
#define REG_WIN1H      *(volatile u16*)0x4000042
#define REG_WIN1X      *(volatile u16*)0x4000042
#define REG_WIN0V      *(volatile u16*)0x4000044
#define REG_WIN0Y      *(volatile u16*)0x4000044
#define REG_WIN1V      *(volatile u16*)0x4000046
#define REG_WIN1Y      *(volatile u16*)0x4000046
#define REG_WININ      *(volatile u16*)0x4000048
#define REG_WINOUT     *(volatile u16*)0x400004A
#define REG_MOSAIC     *(volatile u16*)0x400004C
#define REG_BLDCNT     *(volatile u16*)0x4000050
#define REG_BLDALPHA   *(volatile u16*)0x4000052
#define REG_BLDY       *(volatile u16*)0x4000054

#define REG_SOUND1CNT   *(volatile u32*)0x4000060
#define REG_SOUND1CNT_L *(volatile u16*)0x4000060
#define REG_SOUND1CNT_H *(volatile u16*)0x4000062
#define REG_SOUND1CNT_X *(volatile u16*)0x4000064
#define REG_SOUND2CNT_L *(volatile u16*)0x4000068
#define REG_SOUND2CNT_H *(volatile u16*)0x400006C
#define REG_SOUND3CNT   *(volatile u32*)0x4000070
#define REG_SOUND3CNT_L *(volatile u16*)0x4000070
#define REG_SOUND3CNT_H *(volatile u16*)0x4000072
#define REG_SOUND3CNT_X *(volatile u16*)0x4000074
#define REG_SOUND4CNT_L *(volatile u16*)0x4000078
#define REG_SOUND4CNT_H *(volatile u16*)0x400007C
#define REG_SOUNDCNT    *(volatile u32*)0x4000080
#define REG_SOUNDCNT_L  *(volatile u16*)0x4000080
#define REG_SOUNDCNT_H  *(volatile u16*)0x4000082
#define REG_SOUNDCNT_X  *(volatile u16*)0x4000084
#define REG_SOUNDBIAS   *(volatile u16*)0x4000088
#define REG_WAVE_RAM0   *(volatile u32*)0x4000090
#define REG_WAVE_RAM0_L *(volatile u16*)0x4000090
#define REG_WAVE_RAM0_H *(volatile u16*)0x4000092
#define REG_WAVE_RAM1   *(volatile u32*)0x4000094
#define REG_WAVE_RAM1_L *(volatile u16*)0x4000094
#define REG_WAVE_RAM1_H *(volatile u16*)0x4000096
#define REG_WAVE_RAM2   *(volatile u32*)0x4000098
#define REG_WAVE_RAM2_L *(volatile u16*)0x4000098
#define REG_WAVE_RAM2_H *(volatile u16*)0x400009A
#define REG_WAVE_RAM3   *(volatile u32*)0x400009C
#define REG_WAVE_RAM3_L *(volatile u16*)0x400009C
#define REG_WAVE_RAM3_H *(volatile u16*)0x400009E

//-------SOUND REG for old name--------------
#define REG_SG10       *(volatile u32*)0x4000060
#define REG_SG10_L     *(volatile u16*)0x4000060
#define REG_SG10_H     *(volatile u16*)0x4000062
#define REG_SG11       *(volatile u16*)0x4000064
#define REG_SG20       *(volatile u16*)0x4000068
#define REG_SG21       *(volatile u16*)0x400006C
#define REG_SG30       *(volatile u32*)0x4000070
#define REG_SG30_L     *(volatile u16*)0x4000070
#define REG_SG30_H     *(volatile u16*)0x4000072
#define REG_SG31       *(volatile u16*)0x4000074
#define REG_SG40       *(volatile u16*)0x4000078
#define REG_SG41       *(volatile u16*)0x400007C
#define REG_SGCNT0     *(volatile u32*)0x4000080
#define REG_SGCNT0_L   *(volatile u16*)0x4000080
#define REG_SGCNT0_H   *(volatile u16*)0x4000082
#define REG_SGCNT1     *(volatile u16*)0x4000084
#define REG_SGBIAS     *(volatile u16*)0x4000088
#define REG_SGWR0      *(volatile u32*)0x4000090
#define REG_SGWR0_L    *(volatile u16*)0x4000090
#define REG_SGWR0_H    *(volatile u16*)0x4000092
#define REG_SGWR1      *(volatile u32*)0x4000094
#define REG_SGWR1_L    *(volatile u16*)0x4000094
#define REG_SGWR1_H    *(volatile u16*)0x4000096
#define REG_SGWR2      *(volatile u32*)0x4000098
#define REG_SGWR2_L    *(volatile u16*)0x4000098
#define REG_SGWR2_H    *(volatile u16*)0x400009A
#define REG_SGWR3      *(volatile u32*)0x400009C
#define REG_SGWR3_L    *(volatile u16*)0x400009C
#define REG_SGWR3_H    *(volatile u16*)0x400009E
//------------------------------------------

#define REG_FIFO_A     *(volatile u32*)0x40000A0
#define REG_FIFO_A_L   *(volatile u16*)0x40000A0
#define REG_FIFO_A_H   *(volatile u16*)0x40000A2
#define REG_FIFO_B     *(volatile u32*)0x40000A4
#define REG_FIFO_B_L   *(volatile u16*)0x40000A4
#define REG_FIFO_B_H   *(volatile u16*)0x40000A6

//---------------old name-------------------
#define REG_SGFIF0A    *(volatile u32*)0x40000A0
#define REG_SGFIFOA_L  *(volatile u16*)0x40000A0
#define REG_SGFIFOA_H  *(volatile u16*)0x40000A2
#define REG_SGFIFOB    *(volatile u32*)0x40000A4
#define REG_SGFIFOB_L  *(volatile u16*)0x40000A4
#define REG_SGFIFOB_H  *(volatile u16*)0x40000A6

#define REG_DMA0SAD     *(volatile u32*)0x40000B0
#define REG_DMA0SAD_L   *(volatile u16*)0x40000B0
#define REG_DMA0SAD_H   *(volatile u16*)0x40000B2
#define REG_DMA0DAD     *(volatile u32*)0x40000B4
#define REG_DMA0DAD_L   *(volatile u16*)0x40000B4
#define REG_DMA0DAD_H   *(volatile u16*)0x40000B6
#define REG_DMA0CNT     *(volatile u32*)0x40000B8
#define REG_DMA0CNT_L   *(volatile u16*)0x40000B8
#define REG_DMA0CNT_H   *(volatile u16*)0x40000BA
#define REG_DMA1SAD     *(volatile u32*)0x40000BC
#define REG_DMA1SAD_L   *(volatile u16*)0x40000BC
#define REG_DMA1SAD_H   *(volatile u16*)0x40000BE
#define REG_DMA1DAD     *(volatile u32*)0x40000C0
#define REG_DMA1DAD_L   *(volatile u16*)0x40000C0
#define REG_DMA1DAD_H   *(volatile u16*)0x40000C2
#define REG_DMA1CNT     *(volatile u32*)0x40000C4
#define REG_DMA1CNT_L   *(volatile u16*)0x40000C4
#define REG_DMA1CNT_H   *(volatile u16*)0x40000C6
#define REG_DMA2SAD     *(volatile u32*)0x40000C8
#define REG_DMA2SAD_L   *(volatile u16*)0x40000C8
#define REG_DMA2SAD_H   *(volatile u16*)0x40000CA
#define REG_DMA2DAD     *(volatile u32*)0x40000CC
#define REG_DMA2DAD_L   *(volatile u16*)0x40000CC
#define REG_DMA2DAD_H   *(volatile u16*)0x40000CE
#define REG_DMA2CNT     *(volatile u32*)0x40000D0
#define REG_DMA2CNT_L   *(volatile u16*)0x40000D0
#define REG_DMA2CNT_H   *(volatile u16*)0x40000D2
#define REG_DMA3SAD     *(volatile u32*)0x40000D4
#define REG_DMA3SAD_L   *(volatile u16*)0x40000D4
#define REG_DMA3SAD_H   *(volatile u16*)0x40000D6
#define REG_DMA3DAD     *(volatile u32*)0x40000D8
#define REG_DMA3DAD_L   *(volatile u16*)0x40000D8
#define REG_DMA3DAD_H   *(volatile u16*)0x40000DA
#define REG_DMA3CNT     *(volatile u32*)0x40000DC
#define REG_DMA3CNT_L   *(volatile u16*)0x40000DC
#define REG_DMA3CNT_H   *(volatile u16*)0x40000DE

#define REG_TM0D       *(volatile u16*)0x4000100
#define REG_TM0CNT     *(volatile u16*)0x4000102
#define REG_TM1D       *(volatile u16*)0x4000104
#define REG_TM1CNT     *(volatile u16*)0x4000106
#define REG_TM2D       *(volatile u16*)0x4000108
#define REG_TM2CNT     *(volatile u16*)0x400010A
#define REG_TM3D       *(volatile u16*)0x400010C
#define REG_TM3CNT     *(volatile u16*)0x400010E
#define REG_SCD0       *(volatile u16*)0x4000120
#define REG_SCD1       *(volatile u16*)0x4000122
#define REG_SCD2       *(volatile u16*)0x4000124
#define REG_SCD3       *(volatile u16*)0x4000126
#define REG_SCCNT      *(volatile u32*)0x4000128
#define REG_SCCNT_L    *(volatile u16*)0x4000128
#define REG_SCCNT_H    *(volatile u16*)0x400012A
#define REG_P1         	*(volatile u16*)0x4000130
#define REG_KEY         *(volatile u16*)0x4000130
#define REG_P1CNT      *(volatile u16*)0x4000132
#define REG_KEYCNT      *(volatile u16*)0x4000132
#define REG_R          *(volatile u16*)0x4000134
#define REG_HS_CTRL    *(volatile u16*)0x4000140
#define REG_JOYRE      *(volatile u32*)0x4000150
#define REG_JOYRE_L    *(volatile u16*)0x4000150
#define REG_JOYRE_H    *(volatile u16*)0x4000152
#define REG_JOYTR      *(volatile u32*)0x4000154
#define REG_JOYTR_L    *(volatile u16*)0x4000154
#define REG_JOYTR_H    *(volatile u16*)0x4000156
#define REG_JSTAT      *(volatile u32*)0x4000158
#define REG_JSTAT_L    *(volatile u16*)0x4000158
#define REG_JSTAT_H    *(volatile u16*)0x400015A
#define REG_IE         *(volatile u16*)0x4000200
#define REG_IF         *(volatile u16*)0x4000202
#define REG_WSCNT      *(volatile u16*)0x4000204
#define REG_IME        *(volatile u16*)0x4000208
#define REG_PAUSE      *(volatile u16*)0x4000300


/*
---------------------------------------------------
    BASE Globals

    System wide external variables/arrays
    (initialized in mygba_sys.c)
---------------------------------------------------
*/

extern void (*IntrTable[14])(void);

/*
---------------------------------------------------
      BG defines
      These are helper vals for the BG functions
      in HAMlib
---------------------------------------------------
*/

#define BG_0            (0)
#define BG_1            (1)
#define BG_2            (2)
#define BG_3            (3)

#define BG_PRIO_0       (0)
#define BG_PRIO_1       (1)
#define BG_PRIO_2       (2)
#define BG_PRIO_3       (3)

#define BG_ACTIVE_ON    (1)
#define BG_ACTIVE_OFF   (0)

#define BG_MOSAIC_ON    (1)
#define BG_MOSAIC_OFF   (0)

/*
---------------------------------------------------
      WIN defines
      These are helper vals for the Window functions
      in HAMlib
---------------------------------------------------
*/

#define WIN_BG0 0x01
#define WIN_BG1 0x02
#define WIN_BG2 0x04
#define WIN_BG3 0x08
#define WIN_OBJ 0x10


/*
---------------------------------------------------
      OBJ defines
      These are helper vals for the OBJ functions
      in HAMlib
---------------------------------------------------
*/

#define OBJ_MODE_NORMAL             0x00
#define OBJ_MODE_SEMITRANSPARENT    0x01
#define OBJ_MODE_OBJWINDOW          0x02

#define OBJ_SIZE_8X8                 0,0
#define OBJ_SIZE_16X16               0,1
#define OBJ_SIZE_32X32               0,2
#define OBJ_SIZE_64X64               0,3

#define OBJ_SIZE_16X8                1,0
#define OBJ_SIZE_32X8                1,1
#define OBJ_SIZE_32X16               1,2
#define OBJ_SIZE_64X32               1,3

#define OBJ_SIZE_8X16                2,0
#define OBJ_SIZE_8X32                2,1
#define OBJ_SIZE_16X32               2,2
#define OBJ_SIZE_32X64               2,3

/*
---------------------------------------------------
      Palette color defines
      These are helper vals for the Palette functions
      named ham_SetBgPalCol() and ham_SetObjPalCol()
      in HAMlib.
      Thanks to Peter Schraut for these values.
---------------------------------------------------
*/
#define COLOR_BLACK        0x0000
#define COLOR_MAROON       0x0010
#define COLOR_GREEN        0x0200
#define COLOR_OLIVE        0x0210
#define COLOR_NAVY         0x4000
#define COLOR_PURPLE       0x4010
#define COLOR_TEAL         0x4200
#define COLOR_GRAY         0x4210
#define COLOR_SILVER       0x6318
#define COLOR_RED          0x001F
#define COLOR_LIME         0x03E0
#define COLOR_YELLOW       0x03FF
#define COLOR_BLUE         0x7C00
#define COLOR_FUCHSIA      0x7C1F
#define COLOR_WHITE        0x7FFF
#define COLOR_MONEYGREEN   0x6378
#define COLOR_SKYBLUE      0x7B34
#define COLOR_CREAM        0x7BFF
#define COLOR_MEDGRAY      0x5294

/*
---------------------------------------------------
      Special FX defines
      These are helper vals for the ham_Fx functions
      in HAMlib
---------------------------------------------------
*/

// different Blending Modes available
#define FX_MODE_OFF         0
#define FX_MODE_ALPHABLEND  1
#define FX_MODE_LIGHTEN     2
#define FX_MODE_DARKEN      3

// Feed this Macro 0 or 1 to select / deselect a certain Layer
// this is a helper macro that can be used with ham_SetFxMode()
#define FX_LAYER_SELECT(BG0,BG1,BG2,BG3,OBJ,BD) \
        ( \
         (BG0)       | \
        ((BG1) << 1) | \
        ((BG2) << 2) | \
        ((BG3) << 3) | \
        ((OBJ) << 4) | \
        ((BD)  << 5)    \
        )
/*
---------------------------------------------------
      GFX defines
      Just some general stuff on GBA GFX hardware
      that is not related to any registers.
---------------------------------------------------
*/

#define GFX_MODE3_WIDTH  240
#define GFX_MODE4_WIDTH  240
#define GFX_MODE5_WIDTH  160
#define GFX_MODE3_HEIGHT 160
#define GFX_MODE4_HEIGHT 160
#define GFX_MODE5_HEIGHT 120

/*
---------------------------------------------------
      DMA defines
      Just some general stuff on GBA DMA hardware
      that is not related to any specific registers.
---------------------------------------------------
*/


#define DMA_STARTAT_NOW			0
#define DMA_STARTAT_VBL			1
#define DMA_STARTAT_HBL			2
#define DMA_STARTAT_SOUND_FIFO	3


#define DMA_TRANSFER_16BIT		0
#define DMA_TRANSFER_32BIT		1

/*
---------------------------------------------------

      Music defines
	  (GBC/GBA specific frequency table)
      Very experimental, only for playing around
	  Actually thought of removing these, but if you
	  wanna do some silly music, you might like them :)
---------------------------------------------------
*/

#define SND_FREQU_A_1		1750
#define SND_FREQU_H_1		1782
#define SND_FREQU_C_2		1797
#define SND_FREQU_CIS_2		1811
#define SND_FREQU_D_2		1824
#define SND_FREQU_DIS_2		1837
#define SND_FREQU_E_2		1849
#define SND_FREQU_F_2		1860
#define SND_FREQU_FIS_2		1870
#define SND_FREQU_G_2		1880
#define SND_FREQU_GIS_2		1890
#define SND_FREQU_A_2		1899
#define SND_FREQU_CIS_2		1811


/*
---------------------------------------------------

    Interrupt table enumeration

---------------------------------------------------
*/

#define INT_TYPE_VBL    0
#define INT_TYPE_HBL    1
#define INT_TYPE_VCNT   2
#define INT_TYPE_TIM0   3
#define INT_TYPE_TIM1   4
#define INT_TYPE_TIM2   5
#define INT_TYPE_TIM3   6
#define INT_TYPE_SIO    7
#define INT_TYPE_DMA0   8
#define INT_TYPE_DMA1   9
#define INT_TYPE_DMA2   10
#define INT_TYPE_DMA3   11
#define INT_TYPE_KEY    12
#define INT_TYPE_CART   13

/*
---------------------------------------------------

Save RAM types supported by HAMlib. See the Save RAM
documentation for details

---------------------------------------------------
*/
#define RAM_TYPE_SRAM_256K   0x00
#define RAM_TYPE_EEPROM_4K   0x01
#define RAM_TYPE_EEPROM_64K  0x02
#define RAM_TYPE_UNDEFINED   0xFF


/*
---------------------------------------------------
---------------------------------------------------

      Memory Map related

---------------------------------------------------
---------------------------------------------------
*/

/*
------------------------------
Memory Map Base locations
------------------------------
*/


//Memory locations

#define MEM_SYSROM			0x00000000	// System ROM, for BIOS Calls
#define MEM_EXRAM			0x02000000	// External WRAM, slow, also used for Multiboot uploads
#define MEM_RAM				0x03000000	// Fast CPU internal RAM
#define MEM_IO				0x04000000	// Register Base, all HW Registers are in here.
#define MEM_PAL				0x05000000	// Palette Base
#define MEM_PAL_BG			0x05000000	// Palette for BG
#define MEM_PAL_OBJ			0x05000200	// Palette for OBJ
#define MEM_VRAM			0x06000000	// GBA Video RAM
#define MEM_BG				0x06000000	// GBA Video RAM (in BG mode)
#define MEM_OBJ				0x06010000  // OBJ memoryspace (32 kBytes)
#define MEM_OAM			0x07000000	// Object control space for sprites
#define MEM_ROM0			0x08000000	// Rom Space 0 (fastest, 0 wait)
#define MEM_ROM1			0x0A000000	// Rom Space 1 (1 wait)
#define MEM_ROM2			0x0C000000	// Rom Space 2 (slowest, 2 wait)
#define MEM_EEPROM			0x0D000000	// Gamepak EEPROM, if any.
#define MEM_SRAM			0x0E000000	// Gamepak SRAM, if any.

// Base block locations
#define MEM_PAL_BG_16(x)    (MEM_PAL_BG	 + ((x)<<5))
#define MEM_PAL_OBJ_16(x)   (MEM_PAL_OBJ + ((x)<<5))

//this define returns a pointer to either the bg palette (0) or the obj palette (1)
#define MEM_PAL_256(x)      (MEM_PAL_BG	 + ((x)<<9))
//the following defines return the memory address of a color palette index
#define MEM_PAL_BG_COL_256(x)   (MEM_PAL_BG	 + ((x)<<1))
#define MEM_PAL_OBJ_COL_256(x)  (MEM_PAL_OBJ + ((x)<<1))

#define MEM_CHR_BB(x)       (MEM_BG + ((x)<<14))
#define MEM_SCR_BB(x)       (MEM_BG + ((x)<<11))
#define MEM_HAMBG_SLOT(x)   (MEM_BG + ((x)<<11))
#define MEM_OAM_ENTRY(x)	(MEM_OAM+ ((x)<<3))
#define MEM_HAMOBJ_SLOT(x)  (MEM_OBJ+ ((x)<<5))

#define MEM_SYSROM_SIZE		    0x00004000
#define MEM_EXRAM_SIZE		    0x00040000
#define MEM_RAM_SIZE		    0x00008000
#define MEM_PAL_SIZE		    0x00000400
#define MEM_VRAM_SIZE		    0x00018000
#define MEM_BG_MODE0_SIZE		0x00010000
#define MEM_BG_MODE1_SIZE		0x00010000
#define MEM_BG_MODE2_SIZE		0x00010000
#define MEM_BG_MODE3_BUFSIZE    0x00014000
#define MEM_BG_MODE4_BUFSIZE    0x0000A000
#define MEM_BG_MODE5_BUFSIZE    0x0000A000
#define MEM_BG_SIZE		        0x00010000
#define MEM_BG_SIZE		        0x00010000
#define MEM_OBJ_SIZE            0x00008000
#define MEM_OAM_SIZE		    0x00000400
#define MEM_ROM0_SIZE		    0x02000000
#define MEM_ROM1_SIZE		    0x02000000
#define MEM_ROM2_SIZE		    0x02000000
#define MEM_SRAM_SIZE		    0x00010000

// Misc important mem locations
#define MEM_SNDFIFO_A			(MEM_IO + 0xA0)
#define MEM_SNDFIFO_B			(MEM_IO + 0xA4)


// Memory Pointers
#define MEM_SYSROM_PTR			 (u8*)  0x00000000	// System ROM, for BIOS Calls
#define MEM_EXRAM_PTR			 (u8*)  0x02000000	// External WRAM, slow, also used for Multiboot uploads
#define MEM_RAM_PTR				 (u8*)  0x03000000	// Fast CPU internal RAM
#define MEM_IO_PTR				 (u8*)  0x04000000	// Register Base, all HW Registers are in here.
#define MEM_PAL_PTR				 (u16*) 0x05000000	// Palette Base
#define MEM_PAL_BG_PTR			 (u16*) 0x05000000	// Palette for BG start
#define MEM_PAL_OBJ_PTR			 (u16*) 0x05000200	// Palette for OBJ start
#define MEM_PAL_COL_PTR(x)		 (u16*) (0x05000000+(x<<1))	// Palette color pointer
#define MEM_VRAM_PTR			 (u16*) 0x06000000	// GBA Video RAM
#define MEM_BG_PTR	             (u16*) 0x06000000	// GBA Video RAM
#define MEM_BG_MODE0_PTR	     (u16*) 0x06000000	// GBA Video RAM
#define MEM_BG_MODE1_PTR	     (u16*) 0x06000000	// GBA Video RAM
#define MEM_BG_MODE2_PTR	     (u16*) 0x06000000	// GBA Video RAM
#define MEM_BG_MODE3_PTR	     (u16*) 0x06000000	// GBA Video RAM
#define MEM_BG_MODE4_PTR(buf)    (u16*) (0x06000000+ (buf) * 0xA000)	// GBA Video RAM
#define MEM_BG_MODE5_PTR(buf)    (u16*) (0x06000000+ (buf) * 0xA000)	// GBA Video RAM
#define MEM_OBJ_PTR              (u16*) 0x06010000   // OBJ memoryspace (32 kBytes)
#define MEM_OAM_PTR				 (u8*)  0x07000000	// Object control space for sprites
#define MEM_ROM0_PTR			 (u8*)  0x08000000	// Rom Space 0 (fastest, 0 wait)
#define MEM_ROM1_PTR			 (u8*)  0x0A000000	// Rom Space 1 (1 wait)
#define MEM_ROM2_PTR			 (u8*)  0x0C000000	// Rom Space 2 (slowest, 2 wait)
#define MEM_SRAM_PTR			 (u8*)  0x0E000000	// Gamepak SRAM, if any.

// Base block pointers to Screen and Character BBs

#define MEM_CHR_BB_PTR(x)       ((u8*) MEM_BG + ((x)*0x4000))
#define MEM_SCR_BB_PTR(x)       ((u8*) MEM_BG + ((x)*0x800))

// Pointers to OAM entries
#define MEM_OAM_ENTRY_PTR(x)	 ((u16*) MEM_OAM_ENTRY(x))
#define MEM_OAM_ATR0_PTR(x)		 ((u16*) (MEM_OAM_ENTRY(x)+0))
#define MEM_OAM_ATR1_PTR(x)		 ((u16*) (MEM_OAM_ENTRY(x)+2))
#define MEM_OAM_ATR2_PTR(x)		 ((u16*) (MEM_OAM_ENTRY(x)+4))
#define MEM_OAM_ROTATR_PTR(set,atrno) ((u16*) (MEM_OAM_ENTRY(set<<2)+(atrno<<3)+6))

// Base block pointers for the HAM BG memory manager

#define MEM_HAMBG_SLOT_PTR(x)       ((u16*) MEM_HAMBG_SLOT(x))
#define MEM_HAMOBJ_SLOT_PTR(x)      ((u16*) MEM_HAMOBJ_SLOT(x))

// General access for memory locations
#define ACCESS_8(location)		*(volatile u8 *)  (location)
#define ACCESS_16(location)		*(volatile u16 *) (location)
#define ACCESS_32(location)		*(volatile u32 *) (location)


// BG Macros define
#define ForceBlankon()  	setb(REG_DISPCNT ,7)
#define ForceBlankoff()  	clrb(REG_DISPCNT ,7)

#define Background0on() 	setb(REG_DISPCNT ,8)
#define Background0off()	clrb(REG_DISPCNT ,8)
                                             
#define Background1on() 	setb(REG_DISPCNT ,9)
#define Background1off()	clrb(REG_DISPCNT ,9)

#define Background2on() 	setb(REG_DISPCNT ,10)
#define Background2off()	clrb(REG_DISPCNT ,10)

#define Background3on() 	setb(REG_DISPCNT ,11)
#define Background3off()	clrb(REG_DISPCNT ,11)

#define Objectson()  	 	setb(REG_DISPCNT ,12)
#define Objectsoff()    	clrb(REG_DISPCNT ,12)

#define Set_Mode0()     	REG_DISPCNT &= 0xFFF8
#define Set_Mode1()     	REG_DISPCNT |= 0x0001; \
						REG_DISPCNT &= 0xFFF9
#define Set_Mode2()     	REG_DISPCNT |= 0x0002; \
						REG_DISPCNT &= 0xFFFA
#define Set_Mode3()     	REG_DISPCNT |= 0x0003; \
						REG_DISPCNT &= 0xFFFB
#define Set_Mode4()     	REG_DISPCNT |= 0x0004; \
						REG_DISPCNT &= 0xFFFC
#define Set_Mode5()     	REG_DISPCNT |= 0x0005; \
						REG_DISPCNT &= 0xFFFD

// key input mask
#define KEY_L		9	// L			
#define KEY_R		8	 // R       
#define KEY_DWN		7	 // DOWN    
#define KEY_UP		6  	// UP      
#define KEY_LF		5 	// LF      
#define KEY_RT		4	// RT      
#define KEY_ST		3	// START   
#define KEY_SL		2	// SELECT  
#define KEY_B		1	// B       
#define KEY_A		0	// A       

#ifdef __cplusplus
}
#endif

#endif
